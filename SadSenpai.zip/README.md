## ZeroBot
**ZeroBot is a simple moderation bot with all basics commands that a bot needs!! This is the First version of this bot and the bot gets updated with new version every month!!**

# Setup
**Import the project into repl.it and then fill out your bot token in config.js file.. Then type npm install in the console and let repl.it install all the packages..
Next after everything is complete run the bot and the bot will come online!! Yes, it's that easy!!**

# Commands 
* `Fun` Joyful commands
* `Info` Server info and more over
* `Moderation` Ban and more over

# Links
**Go support us in [Bot Rewards](https://discord.gg/cARF3Dg3) and also [DiscordDevelopers](https://discord.gg/xVsADN2K) Our 2 small support servers!**

## Credits
**Credits here
Neox And NarutoCodm

# Thank you
***Thank you for being a part of Pequin enjoy its commands etc!***

## Warning
Do NOt Change Credits or you will get copyright strike

## update 
**we Have Added Discord Buttons**
